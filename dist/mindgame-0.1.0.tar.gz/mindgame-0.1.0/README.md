This project about several terminal games 
One of this about riddle even or odd number
This is example for "brain-even" command: 
https://asciinema.org/a/582061

Game about calculate expression and give an answer
This example for "brain-calc" command:
@asciinema@