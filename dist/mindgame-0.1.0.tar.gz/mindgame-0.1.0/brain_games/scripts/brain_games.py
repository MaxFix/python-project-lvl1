#!/usr/bin/env python3
#Запускается командой 'poetry run python -m brain_games.scripts.brain_games' из консоли


def main():
    print("Welcome to the Brain Games!")


if __name__ == '__main__':
    main()
